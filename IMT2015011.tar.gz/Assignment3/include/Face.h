#include "Vertex.h"

class Face{
private:
    vector <int> indicesofVertices;
    Vertex Normal;
    //float Area;
    //float inradius;
    //Vertex incentre;
    //Vertex vectorInPlane;
    //Vertex vectorPerpendicular;
public:
    vector<int> getIndices();
    Face(){
        //Area =0;
        //inradius = 0;
    }
    void addIndices(int i);
    //void CalculateNormal();
    
    Vertex getNormal();
    void setNormal(Vertex);
    
    /*void setArea(float);
    float getArea();
    
    void setInradius(float);
    float getInradius();
    
    void setIncentre(Vertex);
    Vertex getIncentre();
    
    void setVectorInPlane(Vertex);
    Vertex getVectorInPlane();
    
    void setVectorPerpendicular(Vertex);
    Vertex getVectorPerpendicular();*/
};
