//
//  View.hpp
//  Assignment3
//
//  Created by Atharva Deshpande on 16/11/17.
//  Copyright © 2017 Atharva Deshpande. All rights reserved.
//

#ifndef View_hpp
#define View_hpp

#include <stdio.h>
#include "Model.h"
#include "FastTrackball.h"


class View{
private:
    static Model* model;
    static View view;
    static GLdouble myprojectionMatrix[16];
    static GLdouble mymodelViewMatrix[16];
    Trackball trackball;
    float rotation_transform[4][4];
public:
    //static View v;
    
    View(){
        
    };
    View(Model* m){
        this->model = m;
    }
    void init();
    void drawImage();
    void render();
    void headLight();
    static void display();
    static void reshape(int, int);
    static void rotateImage(float, float ,float,float);
    static void setModelScale(float,float,float);
    static void moveObject(float, float, float);
    
};

#endif /* View_hpp */
