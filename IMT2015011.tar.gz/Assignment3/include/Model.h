#include "Lighting.h"


class Model{
    Scene* rootNode;
    //vector<string> arrOfFiles;
    vector<Vertex> positions;
    vector<Vertex> colours;
    vector<string> imageFiles;
    vector<SceneNode*> allScenes;
    Vertex floorColour;
    float height;
    float lightPos;
    float objPos;
public:
    Model();
    Scene* getRoot();
    //Scene* setRoot();
    void setInput(vector<char *>);
    void setMatrixFloor(float mat[4][4]);
    void setScaleFloor(float, float ,float);
    void selectDyanamicImage(float,float,float);
    void setImageFiles(vector<string>);
    SceneNode* getScenes(int i);
    int getNoOfScenes();
};
