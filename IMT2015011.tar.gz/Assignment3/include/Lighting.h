#include "Transformation.h"

class Lighting : public Scene{
private:
    float positionX, positionY, positionZ;
    float directionX, directionY, directionZ;
    float angle,red,green,blue,opacity;
    int num;
public:
    Lighting(){
            
    };
    void setNum(int i);
    void setPosition(float,float,float);
    void setDirection(float, float, float);
    void setAngle(float);
    void setColour(float,float,float,float);
    void renderScene();
};
