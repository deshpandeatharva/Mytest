#include "SceneNode.h"

class Transformation : public Scene{
private:
    float Matrix[4][4];
    float translation[3];
    float rotate[3];
    float scale[3];
public:
    Transformation();
    //float getRotation();
    void setRotation(float,float, float);
    void updateRotation(float, float , float);
    
    //float getTranslation();
    void setTranslation(float, float ,float);
    void updateTranslation(float, float, float);
    
    //float getMatrix();
    void setScale(float,float,float);
    void updateScale(float,float,float);
    
    void setMatrix(float mat[4][4]);
    
    
    void renderScene();
};
