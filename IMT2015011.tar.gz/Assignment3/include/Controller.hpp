//
//  Controller.hpp
//  Assignment3
//
//  Created by Atharva Deshpande on 17/11/17.
//  Copyright © 2017 Atharva Deshpande. All rights reserved.
//

#ifndef Controller_hpp
#define Controller_hpp

#include <stdio.h>
#include "View.hpp"

class Controller{
    static View* view;
    static Controller control;
    bool rotate;
    float move_X, move_Y;
    int spotLight[7];
    int texture;
    int plain;
public:
    static void keyboardEvent(unsigned char,int, int);
    static void mouseEvent(int,int,int,int);
    static void mouseMoveFunc(int, int);
};

#endif /* Controller_hpp */
