#include "Face.h"

class Scene{
private:
    vector<Scene*> arrOfChildren;
public:
    Scene(){
        
    }
    void addChild(Scene*);
    vector<Scene*> getarrOfChildren();
    Scene* getChild(int);
    virtual void renderScene();
};
