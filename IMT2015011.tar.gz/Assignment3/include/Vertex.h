#include <stdio.h>
#include <iostream>
#include <fstream>
#include <vector>
// #include <OpenGL/OpenGL.h>
#include <GL/glut.h>
#include <string>
#include <math.h>
#include "SOIL.h"
//#include "FastTrackball.h"

using namespace std;

class Vertex{
private:
    //int k;
    float x;
    float y;
    float z;
    float r,s;
    vector<Vertex> arrOfNormals;
    Vertex* normal;
public:
    Vertex(float a, float b, float c){
        this->x = a;
        this->y = b;
        this->z = c;
        //k=0;
    }
    Vertex(){
        x=0;
        y=0;
        z=0;
        r=0;
        s=0;
        //normal = new Vertex();
    }
    float getX();
    void setX(float x);
    float getY();
    void setY(float y);
    float getZ();
    void setZ(float z);
    
    float getR();
    void setR(float);
    
    float getS();
    void setS(float);
    
    void computeCoordsTex();
    void computeCylinderTex();
    void vertexNormalize();
    void setNormal();
    Vertex* getNormal();
    void addNormal(Vertex);
    
};
