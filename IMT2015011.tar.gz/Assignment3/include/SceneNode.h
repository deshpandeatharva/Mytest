#include "Scene.h"

class SceneNode : public Scene{
    vector<Vertex> arrOfVertices;
    vector<Face> arrOfFaces;
    Vertex colour;
    //vector<SceneNode*> arrOfChild;
    float X_MAX, X_MIN, Y_MIN, Y_MAX, Z_MAX, Z_MIN;
    int id;
    string imgFile;
    //GLuint text;
    //GLuint tempText;
    GLuint text;
    GLuint tempText;
    
public:
    SceneNode(){
        X_MAX=0;
        X_MIN=0;
        Y_MAX=0;
        Z_MAX=0;
        Y_MIN=0;
        Z_MIN=0;
        //text =0;
        //cout<<"k"<<endl;
        //tempText =0;
    }
    void SetInput(char *file);
    void SetImageFile(string file);
    
    float getX_Max();
    void setX_Max(float);
    
    
    int getId();
    void setId(int);
    float getX_Min();
    void setX_Min(float);
    
    float getY_Max();
    void setY_Max(float);
    
    float getY_Min();
    void setY_Min(float);
    
    float getZ_Max();
    void setZ_Max(float);
    
    float getZ_Min();
    void setZ_Min(float);
    
    void addVertex(Vertex);
    void addFace(Face);
    
    void setColour(Vertex);
    Vertex getColour();
    
    int getTexture();
    
    vector<Vertex> getArrOfVertices();
    vector<Face> getArrOfFaces();
    //vector<SceneNode> getArrOfChilds();
    
    void calculateNormal();
    void centreObject(float,float, float);
    void boundObject(float);
    //void addChild(SceneNode*);
    
    Vertex crossProduct(Vertex, Vertex);
    
    void boundingBox();
    void setTemptext(int);
    
    void readImage();
    void renderScene();
    
    void computeCylinderTex();
    void computeSphereTex();
};
