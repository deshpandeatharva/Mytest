#include "../include/Scene.h"


Scene* Scene :: getChild(int i){
    return arrOfChildren.at(i);
}

vector<Scene*> Scene :: getarrOfChildren(){
    return arrOfChildren;
}

void Scene:: addChild(Scene* s){
    arrOfChildren.push_back(s);
}

void Scene:: renderScene(){
    //int k =0;
    for(int i =0;i<arrOfChildren.size();i++){
        arrOfChildren.at(i)->renderScene();
    }
    //k++;
    // cout<<k<<endl;
}
