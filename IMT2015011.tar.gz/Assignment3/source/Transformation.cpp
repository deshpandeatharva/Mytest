#include "../include/Transformation.h"


Transformation:: Transformation() : Scene(){
    for(int i =0; i<4 ; i++){
        for(int j=0; j<4;j++){
            if(i==j)
                Matrix[i][j]=1;
            else
                Matrix[i][j]=0;
        }
    }
    
    for(int i=0;i<3;i++){
        translation[i]=0;
        rotate[i]=0;
        scale[i]=1;
    }
    
    
}

void Transformation:: setMatrix(float mat[4][4]){
    for (int i=0; i<4; i++) {
        for (int j=0; j<4; j++) {
            Matrix[i][j]= mat[i][j];
        }
    }
}

void Transformation:: renderScene(){
    glPushMatrix();
    glMultMatrixf((float*)Matrix);
    glTranslatef(translation[0], translation[1], translation[2]);
    glScalef(scale[0], scale[1], scale[2]);
    
    Scene :: renderScene();
    
    glPopMatrix();
}

void Transformation:: setTranslation(float x, float y, float z){
    translation[0]=x;
    translation[1]=y;
    translation[2]=z;
}

void Transformation:: updateTranslation(float x, float y, float z){
    translation[0]+=x;
    translation[1]+=y;
    translation[2]+=z;
}

void Transformation:: updateRotation(float x, float y, float z){
    rotate[0]+=x;
    rotate[1]+=y;
    rotate[2]+=z;
    
}

void Transformation:: setScale(float x, float y, float z){
    scale[0] =x;
    scale[1] =y;
    scale[2] =z;
}

void Transformation:: updateScale(float x, float y, float z){
    scale[0]*=x;
    scale[1]*=y;
    scale[2]*=z;
}
