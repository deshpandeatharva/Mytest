//
//  main.cpp
//  Assignment3
//
//  Created by Atharva Deshpande on 09/11/17.
//  Copyright © 2017 Atharva Deshpande. All rights reserved.
//

#include <iostream>
//#include "View.hpp"
#include "../include/Controller.hpp"


/*void init(){
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    //glEnable(GL_LIGHTING);
    //glEnable(GL_TEXTURE_2D);
}*/



int main(int argc, char * argv[]) {
    vector<char *> files;
    for(int i =1; i<argc ; i++){
        files.push_back(argv[i]);
        //cout<<"abc\n";
    }
    /*char *s = "apple.ply";
    for(int i=0;i<5;i++){
        files.push_back(s);
    }*/
    //cout<<files.size()<<"H"<<endl;
    vector<string> images;
    string s1 = "data/world.bmp";
    images.push_back(s1);
    string s2 = "data/floor.bmp";
    images.push_back(s2);
    string s3 = "data/wood.jpg";
    images.push_back(s3);
    string s4 = "data/lamp1.jpg";
    images.push_back(s4);
    string s5 = "data/blue.jpeg";
    images.push_back(s5);
    
    // cout<<images[2]<<"eferf"<<endl;
    
    Model m;
    // cout<<"okayffbeuyfweu\n\n\n";
    m.setImageFiles(images);
    m.setInput(files);
   
    View v(&m);
    //Controller c(&v);
    
    
    //glutInit(&argc, argv);
    glutInit(&argc, argv);
    //glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutInitDisplayMode(GLUT_SINGLE| GLUT_RGB | GLUT_DEPTH);
    glutInitWindowPosition(100, 100);
    glutInitWindowSize(800, 900);
    glutCreateWindow("Assignment3 : 3D");
    v.init();
    glutDisplayFunc(v.display);
    glutKeyboardFunc(Controller :: keyboardEvent);
    glutMouseFunc(Controller :: mouseEvent);
    glutMotionFunc(Controller :: mouseMoveFunc);
    glutReshapeFunc(v.reshape);
    //cout<<"Hell"<<"\n";
    glutMainLoop();
    return 0;
}
