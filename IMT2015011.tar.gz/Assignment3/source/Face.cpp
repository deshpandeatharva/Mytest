#include "../include/Face.h"


void Face :: addIndices(int i){
    indicesofVertices.push_back(i);
}
vector<int> Face:: getIndices(){
    return indicesofVertices;
}
Vertex Face:: getNormal(){
    return Normal;
}
