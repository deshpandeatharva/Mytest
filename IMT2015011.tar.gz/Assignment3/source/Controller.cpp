//
//  Controller.cpp
//  Assignment3
//
//  Created by Atharva Deshpande on 17/11/17.
//  Copyright © 2017 Atharva Deshpande. All rights reserved.
//

#include "../include/Controller.hpp"

View* Controller:: view;
Controller Controller:: control;

void Controller:: mouseMoveFunc(int x, int y){
    if(control.rotate == true){
        float w = glutGet(GLUT_WINDOW_WIDTH);
        float h = glutGet(GLUT_WINDOW_HEIGHT);
        
        float a = (2.0*control.move_X  - w)/(float)w;
        float b = (h- 2.0*control.move_Y)/(float)h;
        float c = (2.0*x - w)/ (float)w;
        float d = (h- 2.0*y)/ (float)h;
        
        View :: rotateImage(a, b, c, d);
        //View:: rotateImage(a, b, c, d);
        
        glutPostRedisplay();
    }
    control.move_X = x;
    control.move_Y = y;
}


void Controller:: mouseEvent(int button, int state, int x, int y){
    if(button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN) {
        control.rotate = true;
        control.move_X = x;
        control.move_Y = y;
    }
    
    else if (state == GLUT_UP && button == GLUT_RIGHT_BUTTON) {
        control.rotate = false;
        
        float w = glutGet( GLUT_WINDOW_WIDTH );
        float h = glutGet( GLUT_WINDOW_HEIGHT );
        
        float a = (2.0*control.move_X - w)/(float)w;
        float b = (h - 2.0*control.move_Y)/(float)h;
        float c = (2.0*x - w)/(float)w;
        float d = (h - 2.0*y)/(float)h;
        
        View :: rotateImage(a, b, c, d);
        //View::rotateImage(a, b, c, d);
        glutPostRedisplay();
    }
    
    else if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN){
        //glDisable(GL_TEXTURE_2D);
        glEnable(GL_COLOR_MATERIAL);
        glDisable(GL_TEXTURE_2D);
        for (int i = 1; i < 7; ++i){
            glDisable(GL_LIGHT0+i);
        }
        View::display();
        
        GLfloat array[3];
        glReadPixels(x, glutGet(GLUT_WINDOW_HEIGHT)-y, 1, 1, GL_RGB, GL_FLOAT, array);
        
        //View::translateObject(array[0], array[1], array[2]);
    	// cout<<"okay\n";
    	//cout<<array[0]<<" "<<array[1]<<" "<<array[2]<<endl;
        View::moveObject(array[0], array[1], array[2]);
        if(control.texture%2 == 1){
            glDisable(GL_COLOR_MATERIAL);
            glEnable(GL_TEXTURE_2D);
        }
        for (int i = 1; i < 7; ++i){
            if (i == 6){
                if (control.spotLight[i]%2 == 0)
                    glEnable(GL_LIGHT0+i);
            }
            else{
                if (control.spotLight[i]%2 == 1)
                    glEnable(GL_LIGHT1+i);
            }
        }
        glutPostRedisplay();
    }
}


    void Controller :: keyboardEvent(unsigned char key, int x, int y){
        float scale = 1.5;
        if(key == 27){
            exit(0);
        }
        
        if(key == '1'){
            control.spotLight[1]++;
            if(control.spotLight[1]%2==1){
                glEnable(GL_LIGHT1);
            }
            else
                glDisable(GL_LIGHT1);
        }
        
        if(key == '2'){
            control.spotLight[2]++;
            if(control.spotLight[2]%2==1){
                glEnable(GL_LIGHT2);
            }
            else
                glDisable(GL_LIGHT2);
        }
        
        if(key == '3'){
            control.spotLight[3]++;
            if(control.spotLight[3]%2==1){
                glEnable(GL_LIGHT3);
            }
            else
                glDisable(GL_LIGHT3);
        }
        
        if(key == '4'){
            control.spotLight[4]++;
            if(control.spotLight[4]%2==1){
                glEnable(GL_LIGHT4);
            }
            else
                glDisable(GL_LIGHT4);
        }
        
        if(key == '5'){
            control.spotLight[5]++;
            if(control.spotLight[5]%2==1){
                glEnable(GL_LIGHT5);
            }
            else
                glDisable(GL_LIGHT5);
        }
        
        if(key == 'z'){
            control.spotLight[6]++;
            if(control.spotLight[6]%2==1){
                glEnable(GL_LIGHT6);
            }
            else
                glDisable(GL_LIGHT6);
        }
        
        if(key == 't'){
            control.texture++;
            if(control.texture%2==1){
                glEnable(GL_LIGHT6);
                glDisable(GL_COLOR_MATERIAL);
                glEnable(GL_TEXTURE_2D);
            }
            else{
                glEnable(GL_COLOR_MATERIAL);
                glDisable(GL_TEXTURE_2D);
            }
        }
        
        if(key == '+'){
            view->setModelScale(scale, scale, scale);
            //View :: setModelScale(scale, scale, scale);
        }
        if(key == '-'){
            view->setModelScale(1/scale, 1/scale, 1/scale);
        }
        glutPostRedisplay();
        
}
