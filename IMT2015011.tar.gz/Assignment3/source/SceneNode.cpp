#include "../include/SceneNode.h"

float SceneNode:: getX_Max(){
    return X_MAX;
}
void SceneNode:: setX_Max(float x){
    X_MAX = x;
}

float SceneNode:: getX_Min(){
    return X_MIN;
}
void SceneNode:: setX_Min(float x){
    X_MIN = x;
}

float SceneNode:: getY_Max(){
    return Y_MAX;
}
void SceneNode:: setY_Max(float y){
    Y_MAX = y;
}

float SceneNode:: getY_Min(){
    return Y_MIN;
}
void SceneNode:: setY_Min(float y){
    Y_MIN = y;
}

float SceneNode:: getZ_Max(){
    return Z_MAX;
}
void SceneNode:: setZ_Max(float z){
    Z_MAX = z;
}

float SceneNode:: getZ_Min(){
    return X_MIN;
}
void SceneNode:: setZ_Min(float z){
    Z_MIN = z;
}


vector<Face> SceneNode:: getArrOfFaces(){
    return arrOfFaces;
}
vector<Vertex> SceneNode:: getArrOfVertices(){
    return arrOfVertices;
}

Vertex SceneNode:: crossProduct(Vertex v1, Vertex v2){
    Vertex temp;
    temp.setX((v1.getY()*v2.getZ()) - (v1.getZ()*v2.getY()));
    temp.setY((v1.getZ()*v2.getX())- (v1.getX()*v2.getZ()));
    temp.setZ((v1.getX()*v2.getY())-(v1.getY()*v2.getX()));
    
    return temp;
}

void SceneNode:: calculateNormal(){
    for(int i =0; i<arrOfFaces.size();i++){
        Vertex v1;
        Vertex v2;
        Vertex normTemp;
        Face tempFace = arrOfFaces.at(i);
        // cout<<arrOfVertices.size()<<endl;
        v1.setX(arrOfVertices.at(tempFace.getIndices().at(2)).getX() - arrOfVertices.at(tempFace.getIndices().at(0)).getX());
        v1.setY(arrOfVertices.at(tempFace.getIndices().at(2)).getY() - arrOfVertices.at(tempFace.getIndices().at(0)).getY());
        v1.setZ(arrOfVertices.at(tempFace.getIndices().at(2)).getZ() - arrOfVertices.at(tempFace.getIndices().at(0)).getZ());
        
        v2.setX(arrOfVertices.at(tempFace.getIndices().at(1)).getX() - arrOfVertices.at(tempFace.getIndices().at(0)).getX());
        v2.setY(arrOfVertices.at(tempFace.getIndices().at(1)).getY() - arrOfVertices.at(tempFace.getIndices().at(0)).getY());
        v2.setZ(arrOfVertices.at(tempFace.getIndices().at(1)).getZ() - arrOfVertices.at(tempFace.getIndices().at(0)).getZ());
        // cout<<i<<"H"<<endl;
        // cout<<"Hi"<<endl;
        normTemp = crossProduct(v1, v2);
        //normTemp.vertexNormalize();
        // cout<<normTemp.getX()<<"normTemp  "<<normTemp.getY()<<" "<<normTemp.getZ()<<endl;
        //arrOfFaces.at(i).setNormal(normTemp);
        arrOfVertices.at(tempFace.getIndices().at(0)).addNormal(normTemp);
        arrOfVertices.at(tempFace.getIndices().at(1)).addNormal(normTemp);
        arrOfVertices.at(tempFace.getIndices().at(2)).addNormal(normTemp);
        
    }
    // cout<<"SIZE: "<<arrOfVertices.size()<<endl;
    for(int i=0; i < arrOfVertices.size() ; i++ ){
        // cout<<"Hi"<<endl;
        arrOfVertices.at(i).setNormal();
        // cout<<" Vertices "<<arrOfVertices.at(i).getX()<<" "<<arrOfVertices.at(i).getY()<<" "<<arrOfVertices.at(i).getZ()<<endl;
        
    }
    //cout<<endl;
    // cout<<arrOfVertices.size()<<"HO"<<endl;
    // cout<<"Hi"<<endl;
}

void SceneNode:: centreObject(float x, float y, float z){
    for(int i =0; i< arrOfVertices.size();i++){
        // cout<<" Vertices "<<arrOfVertices.at(i).getX()<<" "<<arrOfVertices.at(i).getY()<<" "<<arrOfVertices.at(i).getZ()<<endl;
        arrOfVertices.at(i).setX(arrOfVertices.at(i).getX() - x);
        arrOfVertices.at(i).setY(arrOfVertices.at(i).getY() - y);
        arrOfVertices.at(i).setZ(arrOfVertices.at(i).getZ() - z);
    }
}

void SceneNode:: boundObject(float diff){
    for(int i=0; i<arrOfVertices.size();i++){
        arrOfVertices.at(i).setX(arrOfVertices.at(i).getX()/diff);
        arrOfVertices.at(i).setY(arrOfVertices.at(i).getY()/diff);
        arrOfVertices.at(i).setZ(arrOfVertices.at(i).getZ()/diff);
    }
}

void SceneNode:: addFace(Face f){
    arrOfFaces.push_back(f);
}

Vertex SceneNode:: getColour(){
    return colour;
}

void SceneNode:: setColour(Vertex v){
    colour.setX(v.getX());
    colour.setY(v.getY());
    colour.setZ(v.getZ());
}

void SceneNode::addVertex(Vertex v){
    arrOfVertices.push_back(v);
}

void SceneNode:: SetInput(char *file){
    fstream inputFile;
    inputFile.open(file);
    int numOfVertices = 0;
    int numOffaces=0;
    int verFace=0;
    float x,y,z;
    int faceIndex=0;
    float min_x = 9999999999999;
    float min_y = 9999999999999;
    float min_z = 9999999999999;
    float max_x = -100000000.0;
    float max_y = -100000000.0;
    float max_z = -100000000.0;
    float diff = 0;
    string temp;
    
    while(1){
        inputFile>>temp;
        // cout<<"Hello"<<endl;
        // cout<<temp<<endl;
        if(temp == "end_header")
            break;
        if(temp == "vertex"){
            inputFile>>numOfVertices;
            // cout<<numOfVertices<<endl;
            
        }
        if (temp == "face"){
            inputFile>>numOffaces;
            // cout<<numOffaces<<endl;
        }
    }
    // cout<<numOfVertices<<endl;
    for(int i=0; i<numOfVertices;i++){
        inputFile>>x>>y>>z;
        // cout<<x<<" "<<y<<" "<<z<<endl;
        if(x < min_x){
            // cout<<"In Min_x"<<endl;
            min_x = x;
        }
        if(x > max_x){
            // cout<<"In Min_x"<<endl;
            max_x = x;
        }
        if(y < min_y){
            // cout<<"In Min_x"<<endl;
            min_y = y;
        }
        if(y > max_y){
            // cout<<"In Min_x"<<endl;
            max_y = y;
        }
        if(z < min_z){
            // cout<<"In Min_x"<<endl;
            min_z = z;
        }
        if(z > max_z){
            // cout<<"In Min_x"<<endl;
            max_z = z;
        }
        Vertex temp(x,y,z);
        arrOfVertices.push_back(temp);
    }
    // cout<<max_x<<" "<<min_x<<endl;
    // cout<<max_y<<" "<<min_y<<endl;
    // cout<<max_z<<" "<<min_z<<endl;
    
    for(int i=0; i< arrOfVertices.size();i++){
     // cout<<arrOfVertices.at(i).getX()<<" "<<arrOfVertices.at(i).getY()<<" "<<arrOfVertices.at(i).getZ()<<endl;
     }
    
    for(int i=0; i<numOffaces;i++ ){
        inputFile>>verFace;
        Face temp;
        for(int j=0;j<verFace;j++){
            inputFile>>faceIndex;
            temp.addIndices(faceIndex);
            // cout<<faceIndex<<" ";
        }
        // cout<<endl;
        arrOfFaces.push_back(temp);
    }
    
    //for(int i=0; i < )
    inputFile.close();
    
    
    float avg_x = (min_x + max_x)/2;
    float avg_y = (min_y + max_y)/2;
    float avg_z = (min_z + max_z)/2;
    
    /*if(fabs(min_x - avg_x) > MAX)
     MAX = fabs(min_x - avg_x);
     if(fabs(max_x - avg_x) > MAX)
     MAX = fabs(max_x - avg_x);
     if(fabs(min_y - avg_y) > MAX)
     MAX = fabs(min_y - avg_y);
     if(fabs(max_y - avg_y) > MAX)
     MAX = fabs(max_y - avg_y);
     if(fabs(min_z - avg_z) > MAX)
     MAX = fabs(min_z - avg_z);
     if(fabs(max_z - avg_z) > MAX)
     MAX = fabs(max_z - avg_z);*/
    
    diff = fabs(max_y-min_y);
        
    
    centreObject(avg_x, avg_y, avg_z);
    boundObject(diff);
    
    setX_Max((max_x - avg_x)/diff);
    setX_Min((min_x - avg_x)/diff);
    setY_Max((max_y - avg_y)/diff);
    setY_Min((min_y - avg_y)/diff);
    setZ_Max((max_z - avg_z)/diff);
    setZ_Min((min_z - avg_z)/diff);

    
    calculateNormal();
    //calculateArea();
    //calculateIncircle();

}

void SceneNode:: boundingBox(){
    glColor3f(1.0  ,1.0, 1.0);
    // cout<<"In Bounding Box"<<endl;
    glPolygonMode(GL_FRONT, GL_LINE);
    glPolygonMode(GL_BACK, GL_LINE);
    glBegin(GL_QUADS);
    
    glVertex3f(X_MAX , Y_MAX,  Z_MAX);
    glVertex3f( X_MIN,  Y_MAX,  Z_MAX);
    glVertex3f( X_MIN,  Y_MIN,  Z_MAX);
    glVertex3f( X_MAX,  Y_MIN,  Z_MAX);
    
    glVertex3f( X_MAX,  Y_MAX,  Z_MAX);
    glVertex3f( X_MAX,  Y_MIN,  Z_MAX);
    glVertex3f( X_MAX,  Y_MIN,  Z_MIN);
    glVertex3f( X_MAX,  Y_MAX,  Z_MIN);
    
    glVertex3f( X_MIN,  Y_MIN,  Z_MIN);
    glVertex3f( X_MAX,  Y_MIN,  Z_MIN);
    glVertex3f( X_MAX,  Y_MAX,  Z_MIN);
    glVertex3f( X_MIN,  Y_MAX,  Z_MIN);
    
    glVertex3f( X_MIN,  Y_MIN,  Z_MIN);
    glVertex3f( X_MIN,  Y_MIN,  Z_MAX);
    glVertex3f( X_MIN,  Y_MAX, Z_MAX);
    glVertex3f( X_MIN,  Y_MAX,  Z_MIN);

    glEnd();
    
    glPolygonMode(GL_FRONT, GL_FILL);
    glPolygonMode(GL_BACK, GL_FILL);
}

void SceneNode:: SetImageFile(string file){
    imgFile = file;
    //readImage();
	// cout<<"oka\n";

}

int SceneNode:: getTexture(){
    return text;
}

void SceneNode:: setId(int i){
    id = i;
}

int SceneNode:: getId(){
    // cout<<"Hey"<<endl;
    return id;
    
}


void SceneNode:: readImage(){
    int width =0, height =0;
    //cout<<text<<"Helo"<<endl;
    glGenTextures(1, &text);
    //cout<<text<<"After"<<endl;
    glBindTexture(GL_TEXTURE_2D, text);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    //cout<<imgFile<<endl;
    unsigned char* image = SOIL_load_image(imgFile.c_str(), &width, &height, 0, SOIL_LOAD_RGB);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    SOIL_free_image_data(image);
    tempText = text;
    //cout<<text<<endl;
    //cout<<tempText<<endl;

    //cout<<width<<height<<endl;
}

void SceneNode:: computeSphereTex(){
    for (int i=0; i<arrOfVertices.size(); i++) {
        arrOfVertices.at(i).computeCoordsTex();
    }
}

void SceneNode:: computeCylinderTex(){
    for (int i=0; i<arrOfVertices.size(); i++) {
        arrOfVertices.at(i).computeCylinderTex();
    }
}

void SceneNode:: setTemptext(int t){
    tempText = t;
}


void SceneNode:: renderScene(){
    boundingBox();
    // cout<<"Ho"<<endl;
    //glColor3f(1.0, 1.0, 1.0);
    glBindTexture(GL_TEXTURE_2D, tempText);
    //cout<<arrOfFaces.size()<<endl;
    for (int i=0; i<arrOfFaces.size(); i++) {
        vector<int> temp = arrOfFaces.at(i).getIndices();
        Vertex v1, v2, v3;
        Vertex *n1,*n2,*n3;
        n1 = arrOfVertices.at(temp[0]).getNormal();
        n2=  arrOfVertices.at(temp[1]).getNormal();
        n3 =  arrOfVertices.at(temp[2]).getNormal();
        
        v1 = arrOfVertices.at(temp[0]);
        v2 = arrOfVertices.at(temp[1]);
        v3 = arrOfVertices.at(temp[2]);
        
        glColor3f(colour.getX(), colour.getY(), colour.getZ());
        glBegin(GL_TRIANGLES);
        
        glNormal3f(n1->getX(), n1->getY(), n1->getZ());
        glTexCoord2f(v1.getR(), v1.getS());
        glVertex3f(v1.getX(), v1.getY(), v1.getZ());
        
        /*if(i<2){
        cout<<v1.getR()<<v1.getS()<<endl;
        cout<<v2.getR()<<v2.getS()<<endl;
        cout<<v3.getR()<<v3.getS()<<endl;
        }*/
    
        glNormal3f(n2->getX(), n2->getY(), n2->getZ());
        glTexCoord2f(v2.getR(), v2.getS());
        glVertex3f(v2.getX(), v2.getY(), v2.getZ());
        
        

        glNormal3f(n3->getX(), n3->getY(), n3->getZ());
        glTexCoord2f(v3.getR(), v3.getS());
        glVertex3f(v3.getX(), v3.getY(), v3.getZ());
        
        

        glEnd();
        
    }
    
    Scene :: renderScene();
    
}
