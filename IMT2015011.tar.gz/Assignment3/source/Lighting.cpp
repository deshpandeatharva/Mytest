#include "../include/Lighting.h"


void Lighting:: setColour(float r, float g, float b, float a){
    red = r;
    green = g;
    blue =b;
    opacity = a;
}

void Lighting:: setAngle(float a){
    angle =a;
}

void Lighting:: setPosition(float x, float y, float z){
    positionX =x;
    positionY = y;
    positionZ = z;
}

void Lighting:: setDirection(float x, float y, float z){
    directionX =x;
    directionY= y;
    directionZ = z;
}

void Lighting:: setNum(int i){
    num =i;
}

void Lighting:: renderScene(){
    glPushMatrix();
    
   //glEnable(GL_LIGHTING);
    
    GLfloat positionLight[] ={positionX,positionY,positionZ,1.0};
    GLfloat directionLight[] = {directionX,directionY,directionZ,0.0};
    GLfloat ambientLight[]={red,green,blue,opacity};
    
    //glPointSize(8.0);
    // cout<<positionX<<positionY<<positionZ<<"H"<<endl;
    // cout<<directionX<<directionY<<directionZ<<"H0"<<endl;
    // cout<<num<<endl;
    //if(num==0 || num==1){
        /*glBegin(GL_POINTS);
        glColor3f(0.0, 1.0, 0.0);
        glVertex3f(positionX, positionY, positionZ);
        glEnd();*/
    glLightfv(GL_LIGHT0+num, GL_POSITION, positionLight);
    glLightfv(GL_LIGHT0+num, GL_DIFFUSE, ambientLight);
    glLightfv(GL_LIGHT0+num, GL_AMBIENT, ambientLight);
    //glLightfv(GL_LIGHT0, GL, <#const GLfloat *params#>)
    
        glLightf(GL_LIGHT0+num, GL_SPOT_CUTOFF, angle);
        glLightfv(GL_LIGHT0+num, GL_SPOT_DIRECTION, directionLight);
        glLightf(GL_LIGHT0+num, GL_SPOT_EXPONENT, 1);
        //glEnable(GL_LIGHT0+num);
    //}

    Scene:: renderScene();
    
    glPopMatrix();
}
