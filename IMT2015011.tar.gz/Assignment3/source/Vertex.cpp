
#include "../include/Vertex.h"

float Vertex:: getX(){
    return x;
}
void Vertex:: setX(float x){
    this->x = x;
}
float Vertex:: getY(){
    return y;
}
void Vertex:: setY(float y){
    this->y = y;
}
float Vertex:: getZ(){
    return z;
}
void Vertex:: setZ(float z){
    this->z = z;
}
void Vertex:: vertexNormalize(){
    float temp = (x*x) + (y*y) + (z*z);
    float magnitude = sqrt(temp);
    // cout<<magnitude<<endl;
    x= -x/magnitude;
    y= -y/magnitude;
    z= -z/magnitude;
}

void Vertex:: setNormal(){
    float x=0.0,y=0.0,z=0.0;
    for(int i =0; i< arrOfNormals.size();i++){
        //float x=0.0,y=0.0,z=0.0;
        x= x+ arrOfNormals.at(i).getX();
        y= y+arrOfNormals.at(i).getY();
        z= z+arrOfNormals.at(i).getZ();
        
        // cout<<normal->getX()<<normal->getY()<<normal->getZ()<<"Normals"<<endl;
    }
    //k++;
    // cout<<k<<"K"<<endl;
    // cout<<x<<y<<z<<endl;
    normal = new Vertex();
    normal->setX(x);
    //n->setX(x);
    normal->setY(y);
    normal->setZ(z);
    normal->vertexNormalize();
    // cout<<normal->getX()<<" "<<normal->getY()<<" "<<normal->getZ()<<endl;
}

Vertex* Vertex:: getNormal(){
    return normal;
}

void Vertex:: addNormal(Vertex x){
    arrOfNormals.push_back(x);
}

void Vertex:: setR(float x){
    r= x;
}
float Vertex:: getR(){
    return r;
}

float Vertex:: getS(){
    return s;
}
void Vertex:: setS(float x){
    s=x;
}

void Vertex:: computeCylinderTex(){
    r= (float)(atan2f(z, x)+ 3.14) / (2*3.14);
    s= (float)y;
    if(s > 0.5){
        s = s - 0.5;
    }
    else {
        s = s + 0.5;
    }
    s = -s;
    r = -r;
}

void Vertex:: computeCoordsTex(){
    r= ((atan2f(z, x) + 3.14)/(2*3.14));
    s= (atan2f(z, y*sin(2*3.14*r)))/(2*3.14);
}
