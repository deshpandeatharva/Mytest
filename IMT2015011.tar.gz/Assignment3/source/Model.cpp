//
//  Model.cpp
//  Assignment3
//
//  Created by Atharva Deshpande on 12/11/17.
//  Copyright © 2017 Atharva Deshpande. All rights reserved.
//

#include "../include/Model.h"
#include <GL/glut.h>



/*void Face:: setNormal(Vertex v){
    Normal.setX(v.getX());
    Normal.setY(v.getY());
    Normal.setZ(v.getZ());
}*/








Scene* Model:: getRoot(){
    return rootNode;
}


Model:: Model(){
    Vertex v;
    v.setX(8.0);
    v.setY(0.0);
    v.setZ(8.0);
    positions.push_back(v);
    
    v.setX(-8.0);
    v.setY(0.0);
    v.setZ(8.0);
    positions.push_back(v);
    
    v.setX(-8.0);
    v.setY(0.0);
    v.setZ(-8.0);
    positions.push_back(v);
    
    v.setX(8.0);
    v.setY(0.0);
    v.setZ(-8.0);
    positions.push_back(v);
    
    v.setX(0.0);
    v.setY(0.0);
    v.setZ(0.0);
    positions.push_back(v);
    
    v.setX(1.0);
    v.setY(1.0);
    v.setZ(0.0);
    colours.push_back(v);
    
    v.setX(1.0);
    v.setY(0.0);
    v.setZ(1.0);
    colours.push_back(v);
    
    v.setX(0.0);
    v.setY(1.0);
    v.setZ(1.0);
    colours.push_back(v);
    
    v.setX(0);
    v.setY(0);
    v.setZ(1);
    colours.push_back(v);
    
    v.setX(0.43);
    v.setY(1.0);
    v.setZ(0.23);
    colours.push_back(v);

    v.setX(1.0);
    v.setY(0.0);
    v.setZ(0.0);
    colours.push_back(v);
    
    height =1.1;
    lightPos = 6.1;
    objPos = 3.1;
}

void Model:: setInput(vector<char *> fnames){
    SceneNode* s = new SceneNode();
    Transformation* t = new Transformation();
    Vertex v1, v2,v3,v4;
    Face f1,f2;
    Vertex v;
    v.setX(1.0);
    v.setY(0.0);
    v.setZ(0.0);

    v1.setX(10.0);
    v1.setY(0.0);
    v1.setZ(10.0);
    v1.setR(1);
    v1.setS(1);
    s->addVertex(v1);
    
    
    v2.setX(-10.0);
    v2.setY(0.0);
    v2.setZ(10.0);
    v2.setR(0);
    v2.setS(1);
    s->addVertex(v2);
    
    
    v3.setX(-10.0);
    v3.setY(0.0);
    v3.setZ(-10.0);
    v3.setR(0);
    v3.setS(0);
    s->addVertex(v3);
    
    
    v4.setX(10.0);
    v4.setY(0.0);
    v4.setZ(-10.0);
    v4.setR(1);
    v4.setS(0);
    s->addVertex(v4);
    
    
    f1.addIndices(0);
    f1.addIndices(1);
    f1.addIndices(2);
    
    f2.addIndices(2);
    f2.addIndices(3);
    f2.addIndices(0);
    
    s->addFace(f1);
    s->addFace(f2);
    // cout<<"Hi"<<endl;
    s->calculateNormal();
    s->setColour(v);
    s->setId(-1);
    //s->computeSphereTex();
    // cout<<imageFiles.size()<<endl;
    s->SetImageFile("data/floor.jpeg");
    //s->readImage();
    allScenes.push_back(s);
    


    for(int i=0;i<fnames.size();i++){
        // cout<<"Hi"<<endl;
        

        SceneNode* n = new SceneNode();
        Transformation* t1 = new Transformation();
        Lighting* l1 = new Lighting();

        l1->setColour(1.0, 1.0, 1.0, 0.0);
        l1->setPosition(0.0, lightPos, 0.0);
        l1->setDirection(0.0, -1.0, 0.0);
        l1->setNum(i+1);
        //cout<<i<<endl;
        l1->setAngle(45.0);
        n->SetInput(fnames.at(i));
        float x = positions.at(i).getX();
        float y = positions.at(i).getY();
        float z = positions.at(i).getZ();
        // cout<<x<<y<<z<<"H"<<endl;
        //rootNode->addChild(n);
        // cout<<"HO"<<endl;
        n->setColour(colours.at(i));
    	// cout<<"deeefedede\n\n"<<endl;
        n->SetImageFile(imageFiles.at(i));
        allScenes.push_back(n);
        //n->readImage();
        // cout<<"ok\n";
        n->computeCylinderTex();
        //n->computeSphereTex();
    	
        

        if(i == fnames.size()-1){
            n->setId(5);
        }
        else
            n->setId(i);
        // cout<<height<<endl;
        l1->addChild(n);
        t1->updateTranslation(x, y+height, z);
        t1->setScale(2.0,2.0,2.0);
        t1->addChild(l1);
        s->addChild(t1);
        // cout<<"HO"<<endl;
    }
    // cout<<"HO"<<endl;
    // cout<<s->getarrOfChildren().size()<<endl;
    
    rootNode = new Scene();
    t->addChild(s);
    rootNode->addChild(t);
    // cout<<"HO"<<endl;
    // cout<<rootNode->getarrOfChildren().size()<<endl;
}
void Model:: setMatrixFloor(float mat[4][4]){
    Transformation *t = (Transformation*) rootNode->getChild(0);
    t->setMatrix(mat);
}

int Model :: getNoOfScenes(){
    return allScenes.size();
}

void Model:: setScaleFloor(float x, float y, float z){
    Transformation *t = (Transformation*) rootNode->getChild(0);
    t->updateScale(x, y, z);
}

void Model:: setImageFiles(vector<string> file){
	// cout<<file.size()<<"jdasojd"<<endl;
    for(int i =0; i<file.size();i++){
        imageFiles.push_back(file.at(i));
    }
}

SceneNode* Model:: getScenes(int i){
            return allScenes.at(i);
        }

void Model:: selectDyanamicImage(float red, float green, float blue){
    float x;
    //cout<<red<<" "<<green<<" "<<blue<<" Select"<<endl;
    Transformation* t1 = (Transformation*) rootNode->getChild(0);
    SceneNode* f = (SceneNode*) t1->getChild(0);
    Transformation* t2 = (Transformation*) f->getChild(4);
    SceneNode *obj = (SceneNode*) t2->getChild(0)->getChild(0);
   //cout<<"asdasd"<<endl;
    //cout<<colours.size()<<"Size of colours"<<endl;
    //cout<<positions.size()<<"Size of positions"<<endl;
    for(int i =0; i< colours.size() ; i++){
        if((red == colours.at(i).getX() && green == colours.at(i).getY() && blue == colours.at(i).getZ() ) ){
            if(i==colours.size() -1 || i==colours.size() -2){
                //cout<<colours[i].getX()<<colours[i].getY()<<colours[i].getZ()<<endl;
                x = height;
                obj->setTemptext(obj->getTexture());
                //cout<<i<<"HEllo"<<endl;
            }
            else{
                Transformation* t_s = (Transformation*) f->getChild(i);
                SceneNode* o_s = (SceneNode*) t_s->getChild(0)->getChild(0);
                obj->setTemptext(o_s->getTexture());
                x =  objPos;
                //cout<<o_s->getTexture()<<endl;
                //cout<<"else"<<endl;
            }
            //cout<<i<<"Before break"<<endl;
            //cout<<positions.at(i).getX()<<" X "<< positions.at(i).getY()<<" Y "<< positions.at(i).getZ()<<" Z "<<endl;
            t2->setTranslation(positions[i].getX(), positions[i].getY()+x, positions[i].getZ());
           	//cout<<i<<"After break"<<endl;
            break;

            //cout<<i<<"In if"<<endl;
        }
        
    }
    
}


