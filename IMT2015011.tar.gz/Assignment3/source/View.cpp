//
//  View.cpp
//  Assignment3
//
//  Created by Atharva Deshpande on 16/11/17.
//  Copyright © 2017 Atharva Deshpande. All rights reserved.
//

#include "../include/View.hpp"
Model* View::model;
View View:: view;
//View View:: v;

void View:: display(){
    View v;
    v.render();
}

void View :: drawImage(){
    //cout<<"HO"<<endl;
    model->getRoot()->renderScene();
}

void View:: rotateImage(float x, float y, float z, float w){
    view.trackball.rotate(x, y, z, w);
    
    view.trackball.rotationMatrix(view.rotation_transform);
    model->setMatrixFloor(view.rotation_transform);
}

void View:: setModelScale(float x, float y, float z){
    model->setScaleFloor(x, y, z);
}

void View:: moveObject(float r, float g, float b){
    model->selectDyanamicImage(r, g, b);
}

void View:: headLight(){
    glEnable(GL_LIGHTING);
    //glEnable(GL_COLOR_MATERIAL);
    GLfloat lightPosition[] = {0.0,10.0,30.0,0.0f};
    GLfloat lightAmbient[] = {1.0f,1.0f,1.0f,1.0f};
    
    glLightfv(GL_LIGHT6, GL_POSITION, lightPosition);
    glLightfv(GL_LIGHT6, GL_DIFFUSE, lightAmbient);
    glLightfv(GL_LIGHT6, GL_AMBIENT, lightAmbient);
    
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lightAmbient);
    //glEnable(GL_LIGHT6);
}

void View:: render(){
    //cout<<"HO"<<endl;
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0.0,10.0,30.0,0.0,0.0,0.0,0.0,1.0,0.0);
    //cout<<"HO"<<endl;
    //glEnable(GL_TEXTURE_2D);
    //GLfloat light[] = {1.0,1.0,1.0,1.0};
    /*GLenum err;
    while((err = glGetError()) != GL_NO_ERROR){
        cout<<"H"<<endl;
        cerr<<"Open Gl Error: "<< err << endl;
    }*/
    headLight();
    glPushMatrix();
    //glLightModelfv(GL_LIGHT_MODEL_AMBIENT, light);
    drawImage();
    
    glPopMatrix();
    
    glFlush();
    glutSwapBuffers();
}

void View :: init(){
	glClearColor(0.0,0.0,0.0,0.0);
    glColor3f(0.0,0.0,0.0);
    glEnable(GL_NORMALIZE);
    glColorMaterial(GL_FRONT, GL_AMBIENT);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_LIGHTING);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    for(int i =0; i< model->getNoOfScenes() ;i++){
        SceneNode* n = model->getScenes(i);
        n->readImage();
    }
    //glEnable(GL_TEXTURE_2D);
	//glEnable(GL_LIGHT6);
}

void View::reshape(int width,int height){
    float ratio =  ((float) width) / ((float) height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, ratio, 1.0, 100.0);
    glMatrixMode(GL_MODELVIEW);
    glViewport(0, 0, width, height);
    glutPostRedisplay();
}

