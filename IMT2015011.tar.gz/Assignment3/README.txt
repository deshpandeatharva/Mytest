To compile :  make

To run :  bin/./main data/<filename1> data/<filename2> data/<filename3> data/<filename4> data/<filename5> 


Description of Input: The first four arguments are the static objects and the 5th is the movable object.


Instructions to play with the objects:
1) The number keys from '1' to '5' to be used to switch on and off each spotlight
2) The key 't' is to enable and disable the texture rendering mode
3) Press the key 'z' for headlight
4) Press the right-click and drag on screen for rotation.
5) Press right click to select a static object to pick it and translate the movable object above it
